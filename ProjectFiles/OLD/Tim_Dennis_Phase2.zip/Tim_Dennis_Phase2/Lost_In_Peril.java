/**
 * 
 */
package com.freebandz.lost_in_peril.desktop;

/**
 * @author timmay54
 * April 6th 2019 11:40 AM
 */
public class Lost_In_Peril {

	/**
	 * @param args
	 */

}

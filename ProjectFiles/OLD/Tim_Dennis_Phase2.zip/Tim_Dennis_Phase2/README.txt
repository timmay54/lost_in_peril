These java files only work when ran inside of the .JAR file
The file must have permissions to be executed to work.
Source code files are for grading really, since they dont work outside of the package
